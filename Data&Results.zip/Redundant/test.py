import cv2
import numpy as np
from deepgaze-master.deepgaze.color_classification import HistogramColorClassifier

my_classifier = HistogramColorClassifier(channels=[0,1,2], hist_size=[128,128,128], hist_range=[0,256,0,256,0,256], hist_type='BGR')
# add more models
model_1 = cv2.imread('model_1.png') #Flash Model
my_classifier.addModelHistogram(model_1)
model_2 = cv2.imread('model_2.png') #Batman Model
my_classifier.addModelHistogram(model_2)
# testing classifier
image = cv2.imread('image_2.jpg') #Batman Test
comparison_array = my_classifier.returnHistogramComparisonArray(image, method="intersection")

probability_array = comparison_array / np.sum(comparison_array)
returnHistogramComparisonArray()

