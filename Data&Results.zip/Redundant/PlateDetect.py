from __future__ import print_function
from sklearn.externals import joblib
from hog import HOG
import dataset
import argparse
import mahotas
import cv2
import imutils
import numpy as np
#
def get_contour_precedence(contour, cols):
    tolerance_factor = 10
    origin = cv2.boundingRect(contour)
    return ((origin[1] // tolerance_factor) * tolerance_factor) * cols + origin[0]
#
ap = argparse.ArgumentParser()
ap.add_argument("-m", "--model", required = True,help = "path to where the model will be stored")
ap.add_argument("-i", "--image", required=True, help="Path to the image")
args = vars(ap.parse_args())
#
model = joblib.load(args["model"])
hog = HOG(orientations=18, pixelsPerCell=(10,10), cellsPerBlock=(1,1), transform=True)
#
img = cv2.imread(args["image"])
pic = img.copy()
image = img.copy()
# converting to grayscale
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# removing noises
image = cv2.GaussianBlur(image, (5,5), 0)
# finding lines 
sobelX = cv2.Sobel(image, cv2.CV_64F, 1, 0)
sobelX = np.uint8(np.absolute(sobelX))
# thresholding using Otsu's method to get binary image
T = mahotas.thresholding.otsu(sobelX)
thresh = sobelX.copy()
thresh[thresh > T] = 255
thresh[thresh < 255] = 0
# Morphological Operations
element = cv2.getStructuringElement(cv2.MORPH_RECT, (14,2))
connected = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, element)
# contours
(cnts, _) = cv2.findContours(connected, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cnts.sort(key=lambda x:get_contour_precedence(x, image.shape[1]))
for c in cnts:
  (x,y,w,h) = cv2.boundingRect(c)
  if w>=75 and h>=25 and y>=image.shape[1]/8 and y<7*image.shape[1]/8 and w<=6.5*h and w>1.5*h and x<=3*image.shape[0]/4:
	roi = connected[y:y+h, x:x+w]
	cv2.rectangle(img, (x,y), (x+w,y+h), (0,0,255), 2)
	crop_img = pic[y:y+h, x:x+w]
	dim = (250,60)
	c1 = cv2.resize(crop_img, dim, interpolation=cv2.INTER_AREA)
	c2 = cv2.cvtColor(c1, cv2.COLOR_BGR2GRAY)
	c3 = cv2.GaussianBlur(c2, (3,3), 1)
	c4 = dataset.deskew(c3, 20)
  	c4 = dataset.center_extent(c4, (20,20))
 	hist = hog.describe(c4)
	plate = model.predict([hist])[0]
	cv2.putText(img, str(plate), (x-10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,255,0), 2)
	print("I think that the character is : {}".format(plate))
	cv2.imshow("image", img)
	cv2.waitKey(0)

	if plate == 1:
		dim = (250,60)
		c3 = cv2.resize(c3,dim,interpolation=cv2.INTER_AREA)
  		cv2.imwrite("PRO/Phase2/plate19.jpg",c3)

cv2.imwrite("PRO/Phase1/19.jpg",img)  		